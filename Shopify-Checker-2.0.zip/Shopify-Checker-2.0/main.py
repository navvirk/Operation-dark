import logging
import asyncio
import time
from datetime import datetime
from typing import Callable, Dict, Any, Awaitable

import aiohttp  # used by _prewarm_shopify_api() at startup

from aiogram import Bot, Dispatcher, types, F, Router, BaseMiddleware
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties
from aiogram.filters import Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

from database import get_user, create_user, get_user_credits, update_credits, get_collection
from gate import on_command, off_command
from fb import setup_feedback_handler, feedback_cmd, router as fb_router
from stats import leaderboard_command as stats_command
from tools.binn import binn_command
from cmds import cmds_command, router as cmds_router
from broad import broad_command, router as broad_router
from ban import ban_command, unban_command, BanMiddleware, router as ban_router
from maintenance import maintenance_command, MaintenanceMiddleware, router as maintenance_router
from status import vps_command, router as status_router
from admin import router as admin_router, admin_command, restart_command
from admin_prx import router as prx_router, prx_command
from admin_sites import router as sites_router, addsites_command, checksite_command

from sub import (
    sub_command, rc_command, suball_command, g_code_command, g_access_command,
    claim_command, info_command, rsub_command, adcr_command
)
from proxy import proxy_command, checkproxy_command, clearproxy_command

from gates.sh import sh_command, sh_callback_handler


from mass_gates.msh import (
    router as msh_router, MshStopCallback, MshResultCallback,
    handle_stop_callback as msh_stop_handler,
    handle_result_callback as msh_result_handler,
)

from mass_gates.sitechk import (
    sitechk_command, addsite_command, siteall_command,
    removeall_command, dedupe_command, proxyinfo_command, resetproxy_command
)

import payments as pay_sys

BOT_TOKEN = "8998188441:AAFpm0rOvCYwB2g23w9jDTHa6ahZButJu_w"
WEBHOOK_URL = f"https://web-production-c2d03.up.railway.app/{BOT_TOKEN}"
WEBHOST = "0.0.0.0"
WEBPORT = 8080

# 🔧 Set True to run locally with polling, False for Railway webhook
LOCAL_MODE = True

LOG_CHANNEL_ID = -1004385682090 # fallback numeric — overridden by resolver at startup
LOG_CHANNEL_HANDLE = "https://t.me/+hTqA4ccByRs0YzUx"   # public handle resolved to ID on startup
BOT_LINK = "https://t.me/ShopifyxoBot"

REQUIRED_CHANNEL_ID = -1004385682090  # placeholder, resolved at startup  # fallback numeric — overridden by resolver at startup
REQUIRED_CHANNEL_HANDLE = "@darkxrangers"   # public handle resolved to ID on startup
REQUIRED_GROUP_ID = -1004385682090  # placeholder, resolved at startup  # fallback numeric — overridden by resolver at startup
REQUIRED_GROUP_HANDLE = "https://t.me/+hTqA4ccByRs0YzUx"   # public handle resolved to ID on startup
CHANNEL_LINK = "https://t.me/darkxrangers"
GROUP_LINK = "https://t.me/+hTqA4ccByRs0YzUx"

JOIN_TEXT = (
    "<tg-emoji emoji-id='5350572310627632617'>⚠️</tg-emoji> <b>Access Restricted!</b>\n\n"
    "You must join <b>both</b> our channel and group before using any command — "
    "even if you have a premium plan.\n\n"
    "Steps ➛\n"
    "1. Tap <b>Join Channel</b>\n"
    "2. Tap <b>Join Group</b>\n"
    "3. Tap <b>Verify</b>\n\n"
    "━━━━━━━━━━━━━━━━\n"
    f"Channel ➛ <a href=\"{CHANNEL_LINK}\">@darkxrangers</a>\n"
    f"Group ➛ <a href=\"{GROUP_LINK}\">https://t.me/+hTqA4ccByRs0YzUx</a>"
)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PREMIUM EMOJI IDS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EMOJI_RED_TICK   = "6147565374289220368"
EMOJI_BLUE_TICK  = "5278628026416909103"
EMOJI_LIGHTNING  = "5350835008007324644"
EMOJI_STAR       = "5359686514697576863"
EMOJI_FIRE       = "6186076099764555777"
EMOJI_CROWN      = "6338940587193930733"
EMOJI_EPIC       = "5310296284874159738"
EMOJI_DRAGON     = "5226578782340553954"
EMOJI_GUN        = "5440406404936524730"
EMOJI_WHITE_STAR = "5247131412032670246"

PRICING_TEXT = (
    f'<b>Access ➛ ULTRA</b> <tg-emoji emoji-id="6183613910977876404">💎</tg-emoji>\n'
    f'<b>Span ➛</b> [7 DAYS]\n'
    f'<b>Credits ➛</b> 13,000\n'
    f'<b>Price ➛</b> $10\n'
    f'━━━━━━━━━━━━━━━━\n'
    f'<b>Access ➛ SUPER</b> <tg-emoji emoji-id="6183613910977876404">💎</tg-emoji>\n'
    f'<b>Span ➛</b> [15 DAYS]\n'
    f'<b>Credits ➛</b> 23,000\n'
    f'<b>Price ➛</b> $15\n'
    f'━━━━━━━━━━━━━━━━\n'
    f'<b>Access ➛ ULTIMATE</b> <tg-emoji emoji-id="6183613910977876404">💎</tg-emoji>\n'
    f'<b>Span ➛</b> [30 DAYS]\n'
    f'<b>Credits ➛</b> 53,000\n'
    f'<b>Price ➛</b> $30'
)

logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()

dp.include_router(msh_router)
dp.include_router(cmds_router)
dp.include_router(fb_router)
dp.include_router(ban_router)
dp.include_router(broad_router)
dp.include_router(status_router)
dp.include_router(admin_router)
dp.include_router(prx_router)
dp.include_router(sites_router)
dp.include_router(maintenance_router)

router = Router()
dp.include_router(router)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# MEMBERSHIP CACHE — avoids Telegram API calls on every message
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Cache structure: {user_id: (is_member: bool, expires_at: float)}
_MEMBERSHIP_CACHE: Dict[int, tuple] = {}
_MEMBERSHIP_CACHE_TTL = 60  # seconds — positive results cached 60s, negatives 15s
_MEMBERSHIP_LOCK: Dict[int, asyncio.Lock] = {}
_MEMBERSHIP_LOCK_MAP_LOCK = asyncio.Lock()

_VALID_STATUSES = {"member", "administrator", "creator"}


async def _get_user_lock(user_id: int) -> asyncio.Lock:
    async with _MEMBERSHIP_LOCK_MAP_LOCK:
        if user_id not in _MEMBERSHIP_LOCK:
            _MEMBERSHIP_LOCK[user_id] = asyncio.Lock()
        return _MEMBERSHIP_LOCK[user_id]


async def check_membership(user_id: int, bot_instance: Bot) -> bool:
    now = time.monotonic()

    # Fast path: serve from cache if still valid
    cached = _MEMBERSHIP_CACHE.get(user_id)
    if cached is not None:
        is_member, expires_at = cached
        if now < expires_at:
            return is_member

    # Deduplicate concurrent checks for the same user via per-user lock
    lock = await _get_user_lock(user_id)
    async with lock:
        # Re-check cache inside the lock — another coroutine may have filled it
        cached = _MEMBERSHIP_CACHE.get(user_id)
        if cached is not None:
            is_member, expires_at = cached
            if now < expires_at:
                return is_member

        try:
            ch, gr = await asyncio.gather(
                asyncio.ensure_future(bot_instance.get_chat_member(REQUIRED_CHANNEL_ID, user_id)),
                asyncio.ensure_future(bot_instance.get_chat_member(REQUIRED_GROUP_ID, user_id)),
            )
            is_member = ch.status in _VALID_STATUSES and gr.status in _VALID_STATUSES
        except Exception as e:
            logging.warning(f"Membership check failed for {user_id}: {e}")
            # On error, assume member to avoid blocking legitimate users temporarily
            is_member = True

        # Cache positives for 60s, negatives for 15s (so denied users don't wait long)
        ttl = _MEMBERSHIP_CACHE_TTL if is_member else 15
        _MEMBERSHIP_CACHE[user_id] = (is_member, now + ttl)
        return is_member


def invalidate_membership_cache(user_id: int):
    """Call this after a user verifies membership so the cache is cleared immediately."""
    _MEMBERSHIP_CACHE.pop(user_id, None)


_JOIN_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="Join Channel", url=CHANNEL_LINK, style="primary", icon_custom_emoji_id=EMOJI_WHITE_STAR)],
    [InlineKeyboardButton(text="Join Group", url=GROUP_LINK, style="primary", icon_custom_emoji_id=EMOJI_EPIC)],
    [InlineKeyboardButton(text="Verify", callback_data="verify_membership", style="success", icon_custom_emoji_id=EMOJI_BLUE_TICK)]
])

ADMIN_IDS = {8909940627}


class MembershipMiddleware(BaseMiddleware):
    async def __call__(self, handler, event: types.Message, data: Dict[str, Any]):
        user = event.from_user
        if not user:
            return await handler(event, data)
        if user.id in ADMIN_IDS:
            return await handler(event, data)
        if not await check_membership(user.id, data["bot"]):
            await event.reply(text=JOIN_TEXT, parse_mode="HTML", reply_markup=_JOIN_KB, disable_web_page_preview=True)
            return
        return await handler(event, data)


dp.message.middleware(MembershipMiddleware())
dp.message.middleware(BanMiddleware())
# Maintenance middleware runs LAST so it overrides ban/membership checks
# when maintenance mode is ON — every non-admin is blocked regardless of
# their ban/membership state.
dp.message.middleware(MaintenanceMiddleware())


@router.callback_query(F.data == "verify_membership")
async def verify_membership_callback(callback: types.CallbackQuery):
    # Invalidate cache so the live check runs fresh
    invalidate_membership_cache(callback.from_user.id)
    joined = await check_membership(callback.from_user.id, callback.bot)
    if joined:
        await callback.answer("<tg-emoji emoji-id='5310296284874159738'>✅</tg-emoji> Verified! You now have full access.", show_alert=True)
        await callback.message.delete()
    else:
        await callback.answer(
            "<tg-emoji emoji-id='5397890704062038337'>❌</tg-emoji> You haven't joined yet!\n\nPlease join both the channel and group first, then click Verify.",
            show_alert=True
        )

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DB HELPERS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
def _db_conn():
    return psycopg2.connect(**DB_CONFIG, cursor_factory=RealDictCursor)

def _ensure_user_sync(user_id, username):
    try:
        if not get_user(user_id):
            create_user(user_id, username or "unknown")
        cr = get_user_credits(user_id)
        if not cr:
            update_credits(user_id, 150)
    except Exception as e:
        logging.error(f"ensure_user {user_id}: {e}")

async def ensure_user_and_credits(user_id, username="unknown"):
    await asyncio.to_thread(_ensure_user_sync, user_id, username)

def _status_sync(user_id):
    is_premium = False
    joined_str = "N/A"
    plan_name = None
    try:
        user = get_user(user_id)
        if user:
            ja = user.get("joined_at")
            if ja and hasattr(ja, "strftime"):
                joined_str = ja.strftime("%Y-%m-%d")
            expiry = user.get("premium_expiry")
            if user.get("is_premium") == 1 and expiry and datetime.now() < expiry:
                is_premium = True
        if is_premium:
            try:
                receipts_col = get_collection("receipts")
                rec = receipts_col.find_one({"user_id": user_id})
                if rec:
                    plan_name = rec.get("plan") or rec.get("plan_name")
            except Exception:
                pass
    except Exception as e:
        logging.error(f"status {user_id}: {e}")
    return is_premium, joined_str, plan_name

async def _get_caption(user) -> str:
    is_premium, joined_str, plan_name = await asyncio.to_thread(_status_sync, user.id)
    ul = f'<a href="tg://user?id={user.id}">{user.first_name}</a>'
    crown       = f'<tg-emoji emoji-id="{EMOJI_CROWN}">👑</tg-emoji>'
    blue_tick   = f'<tg-emoji emoji-id="{EMOJI_BLUE_TICK}">✅</tg-emoji>'
    red_tick    = f'<tg-emoji emoji-id="{EMOJI_RED_TICK}">❌</tg-emoji>'
    epic        = f'<tg-emoji emoji-id="{EMOJI_EPIC}">✨</tg-emoji>'
    if user.id in ADMIN_IDS:
        plan_str = f"<b>ULTIMATE</b> {blue_tick}"
    elif is_premium and plan_name:
        plan_str = f"<b>{plan_name}</b> {blue_tick}"
    elif is_premium:
        plan_str = f"<b>Premium</b> {blue_tick}"
    else:
        plan_str = f"<b>No plan</b> {red_tick}"
    return (
        f"{crown} <b><a href=\"https://t.me/ShopifyxoBot\">Rukia Shopify</a></b>\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"Hi ➛ {ul}\n"
        f"Plan ➛ {plan_str}"
    )

def _loading_caption(user) -> str:
    ul = f'<a href="tg://user?id={user.id}">{user.first_name}</a>'
    crown      = f'<tg-emoji emoji-id="{EMOJI_CROWN}">👑</tg-emoji>'
    lightning  = f'<tg-emoji emoji-id="{EMOJI_LIGHTNING}">⏳</tg-emoji>'
    return (
        f"{crown} <b><a href=\"https://t.me/ShopifyxoBot\">Rukia Shopify</a></b>\n"
        f"━━━━━━━━━━━━━━━━\n"
        f"Hi ➛ {ul}\n"
        f"Plan ➛ <b>Loading…</b> {lightning}"
    )

def mask_receipt_id(receipt_id):
    parts = receipt_id.split('-')
    if len(parts) == 3:
        m = parts[1]
        if len(m) >= 2:
            return f"{parts[0]}-{m[:2]}XX{m[4:]}-{parts[2]}"
    return receipt_id

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PRE-BUILT KEYBOARDS (built once at startup — zero runtime cost)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_MAIN_KB = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🛍 Shopify", callback_data="menu_shopify", style="success", icon_custom_emoji_id="5397981293512243749")],
    [InlineKeyboardButton(text="Channel", url="https://t.me/darkxrangers", style="primary", icon_custom_emoji_id="5388849303982716989"),
     InlineKeyboardButton(text="Group", url=GROUP_LINK, style="primary", icon_custom_emoji_id="5350835008007324644")]
])

def _back(target):
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="« Back", callback_data=target, icon_custom_emoji_id=EMOJI_RED_TICK)]])

_KB_BACK_MAIN   = _back("back_main")
_KB_BACK_GATES  = _back("menu_gates")
_KB_BACK_MASS   = _back("menu_mass_in_gates")
_KB_BACK_AUTH   = _back("menu_auth")
_KB_BACK_CHARGE = _back("menu_charge")

_KB_PRICING = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="💎 Pay Via", callback_data="menu_payment_methods", style="success", icon_custom_emoji_id=EMOJI_FIRE)],
    [InlineKeyboardButton(text="« Back", callback_data="back_main", style="danger", icon_custom_emoji_id=EMOJI_RED_TICK)]
])
_KB_SHOPIFY = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🔍 Single Check", callback_data="info_sh_gate", style="primary", icon_custom_emoji_id=EMOJI_BLUE_TICK)],
    [InlineKeyboardButton(text="⚡ Mass Check",   callback_data="info_msh_gate", style="success", icon_custom_emoji_id=EMOJI_LIGHTNING)],
    [InlineKeyboardButton(text="« Back", callback_data="back_main", style="danger", icon_custom_emoji_id=EMOJI_RED_TICK)]
])

_KB_GATES = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="⚡ Mass Gates", callback_data="menu_mass_in_gates", style="success", icon_custom_emoji_id=EMOJI_LIGHTNING)],
    [InlineKeyboardButton(text="🔐 Auth Gates", callback_data="menu_auth", style="primary", icon_custom_emoji_id=EMOJI_GUN)],
    [InlineKeyboardButton(text="💳 Charge Gates", callback_data="menu_charge", style="primary", icon_custom_emoji_id=EMOJI_FIRE)],
    [InlineKeyboardButton(text="« Back", callback_data="back_main", style="danger", icon_custom_emoji_id=EMOJI_RED_TICK)]
])

_KB_MASS = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="⚡ Shopify 0-20$",  callback_data="info_msh_gate", style="success", icon_custom_emoji_id=EMOJI_DRAGON)],
    [InlineKeyboardButton(text="⚡ Stripe 1$",       callback_data="info_mst_gate", style="success", icon_custom_emoji_id=EMOJI_EPIC)],
    [InlineKeyboardButton(text="⚡ Stripe Hitter",  callback_data="info_stco_gate", style="success", icon_custom_emoji_id=EMOJI_LIGHTNING)],
    [InlineKeyboardButton(text="« Back", callback_data="menu_gates", style="danger", icon_custom_emoji_id=EMOJI_RED_TICK)]
])

_KB_AUTH = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="🔐 Stripe 0$",   callback_data="info_auth_stripe", style="primary", icon_custom_emoji_id=EMOJI_BLUE_TICK)],
    [InlineKeyboardButton(text="🔐 Braintree 0$", callback_data="info_auth_braintree", style="primary", icon_custom_emoji_id=EMOJI_WHITE_STAR)],
    [InlineKeyboardButton(text="🔐 Braintree VBV", callback_data="info_auth_braintree_vbv", style="primary", icon_custom_emoji_id=EMOJI_GUN)],
    [InlineKeyboardButton(text="« Back", callback_data="menu_gates", style="danger", icon_custom_emoji_id=EMOJI_RED_TICK)]
])

_KB_CHARGE = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text="💳 Stripe 1$", callback_data="info_charge_stripe", style="primary", icon_custom_emoji_id=EMOJI_FIRE),
     InlineKeyboardButton(text="💳 PayPal 0.10$", callback_data="info_charge_paypal", style="primary", icon_custom_emoji_id=EMOJI_DRAGON)],
    [InlineKeyboardButton(text="💳 Shopify 5$", callback_data="info_charge_shopify", style="primary", icon_custom_emoji_id=EMOJI_EPIC),
     InlineKeyboardButton(text="💳 Shopify 1$", callback_data="info_charge_shopify", style="primary", icon_custom_emoji_id=EMOJI_FIRE)],
    [InlineKeyboardButton(text="💳 Payfast 0.30$", callback_data="info_charge_payfast", style="primary", icon_custom_emoji_id=EMOJI_GUN),
     InlineKeyboardButton(text="💳 FatZebra 4$", callback_data="info_charge_fatzebra", style="primary", icon_custom_emoji_id=EMOJI_WHITE_STAR)],
    [InlineKeyboardButton(text="💳 NMI 1$", callback_data="info_charge_nmi", style="primary", icon_custom_emoji_id=EMOJI_BLUE_TICK),
     InlineKeyboardButton(text="💳 NMI2 1$", callback_data="info_charge_nmi", style="primary", icon_custom_emoji_id=EMOJI_LIGHTNING)],
    [InlineKeyboardButton(text="💳 BluePay 20$", callback_data="info_charge_bluepay", style="primary", icon_custom_emoji_id=EMOJI_DRAGON),
     InlineKeyboardButton(text="💳 Authorize.net 1$", callback_data="info_charge_authnet", style="primary", icon_custom_emoji_id=EMOJI_EPIC)],
    [InlineKeyboardButton(text="💳 PayWay 1$", callback_data="info_charge_payway", style="primary", icon_custom_emoji_id=EMOJI_FIRE),
     InlineKeyboardButton(text="💳 Razorpay 1₹", callback_data="info_charge_razorpay", style="primary", icon_custom_emoji_id=EMOJI_GUN)],
    [InlineKeyboardButton(text="💳 PayU 1$", callback_data="info_charge_payu", style="primary", icon_custom_emoji_id=EMOJI_WHITE_STAR)],
    [InlineKeyboardButton(text="« Back", callback_data="menu_gates", style="danger", icon_custom_emoji_id=EMOJI_RED_TICK)]
])

_SEP = "━━━━━━━━━━━━━━━━"

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# STATIC MENU LOOKUP — O(1) dict, text+keyboard pre-built
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_PAYMENT_SELECT_TEXT = "<b><tg-emoji emoji-id='5310296284874159738'>✨</tg-emoji> Select Your Plan <tg-emoji emoji-id='5310296284874159738'>✨</tg-emoji>\n\nChoose a plan to proceed with\nsecure crypto payment</b>"

STATIC_MENU_MAP: dict = {
    "menu_pricing": (PRICING_TEXT, _KB_PRICING),
    "menu_shopify": (
        f"┏━━━━━━━━━━━━━━━━━━━━┓\n"
        f"  <tg-emoji emoji-id=\"5397981293512243749\">🐉</tg-emoji> <b>Shopify Gates</b>\n"
        f"┗━━━━━━━━━━━━━━━━━━━━┛\n"
        f"\n"
        f"<tg-emoji emoji-id=\"5310296284874159738\">🔍</tg-emoji> <b>Single Check</b>  <code>/sh cc|mm|yy|cvv</code>\n"
        f"<tg-emoji emoji-id=\"5388849303982716989\">⚡</tg-emoji> <b>Mass Check</b>   <code>/msh cc|mm|yy|cvv</code>\n"
        f"<tg-emoji emoji-id=\"5350572310627632617\">📨</tg-emoji> <b>Reply /msh</b>   to a .txt or text message\n"
        f"{_SEP}",
        InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="« Back", callback_data="back_main", style="danger", icon_custom_emoji_id=EMOJI_RED_TICK)]
        ])
    ),
    "menu_gates": (
        "<b>Gates Status:</b>\n"
        "Auth Gates ➛ <b>3</b>\n"
        "Mass Gates ➛ <b>2</b>\n"
        "Charge Gates ➛ <b>11</b>\n"
        f"{_SEP}\n<b><i>Select a Gate Category</i></b>",
        _KB_GATES
    ),
    "menu_mass_in_gates": ("<b><i>Select a Mass Gate</i></b>", _KB_MASS),
    "menu_auth":          ("<b><i>Select Auth Method</i></b>", _KB_AUTH),
    "menu_charge":        ("<b><i>Select Charge Method</i></b>", _KB_CHARGE),
    "menu_payment_methods": (_PAYMENT_SELECT_TEXT, None),  # kb injected at runtime
    "info_sh_gate": (
        f"{_SEP}\n<b><i>Gate ➛ Shopify Single</i></b>\n<b><i>Command ➛ /sh</i></b>\n"
        f"<b><i>Usage ➛ <code>/sh cc|mm|yy|cvv</code></i></b>\n<b><i>Type ➛ Single Checker</i></b>\n{_SEP}",
        _KB_BACK_MAIN),
    "info_msh_gate": (
        f"{_SEP}\n<b><i>Gate ➛ Shopify 0-20$</i></b>\n<b><i>Command ➛ /msh</i></b>\n"
        f"<b><i>Limit ➛ 2000</i></b>\n<b><i>Type ➛ Mass Checker</i></b>\n<b><i>Stop ➛ 🛑 Button</i></b>\n"
        f"{_SEP}\n<b><i>Gate ➛ Shopify Mass</i></b>\n<b><i>Command ➛ /sh</i></b>\n"
        f"<b><i>Limit ➛ 50 cards</i></b>\n{_SEP}", _KB_BACK_MASS),
    "info_mst_gate": (
        f"{_SEP}\n<b><i>Gate ➛ Stripe 1$</i></b>\n<b><i>Command ➛ /mst</i></b>\n"
        f"<b><i>Limit ➛ 2000</i></b>\n<b><i>Type ➛ Mass Checker</i></b>\n<b><i>Stop ➛ 🛑 Button</i></b>\n{_SEP}",
        _KB_BACK_MASS),
    "info_stco_gate": (
        f"{_SEP}\n<b><i>Gate ➛ Stripe Hitter</i></b>\n<b><i>Command ➛ /stco</i></b>\n"
        f"<b><i>Type ➛ Auto Hitter</i></b>\n<b><i>Stop ➛ 🛑 Button</i></b>\n{_SEP}",
        _KB_BACK_MASS),
    "info_auth_stripe": (
        f"{_SEP}\n<b><i>Gate ➛ Stripe 0$</i></b>\n<b><i>Command ➛ /chk</i></b>\n"
        f"<b><i>Sites Loaded ➛ 16</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_AUTH),
    "info_auth_braintree": (
        f"{_SEP}\n<b><i>Gate ➛ Braintree 0$</i></b>\n<b><i>Command ➛ /b3</i></b>\n"
        f"<b><i>Sites Loaded ➛ 2</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_AUTH),
    "info_auth_braintree_vbv": (
        f"{_SEP}\n<b><i>Gate ➛ Braintree VBV</i></b>\n<b><i>Command ➛ /vbv</i></b>\n"
        f"<b><i>Sites Loaded ➛ 1</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_AUTH),
    "info_charge_stripe": (
        f"{_SEP}\n<b><i>Gate ➛ Stripe 1$</i></b>\n<b><i>Command ➛ /st</i></b>\n"
        f"<b><i>Sites Loaded ➛ 4</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
    "info_charge_paypal": (
        f"{_SEP}\n<b><i>Gate ➛ PayPal 0.10$</i></b>\n<b><i>Command ➛ /pp</i></b>\n"
        f"<b><i>Sites Loaded ➛ 7</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
    "info_charge_shopify": (
        f"{_SEP}\n<b><i>Gate ➛ Shopify 5$</i></b>\n<b><i>Command ➛ /hc</i></b>\n"
        f"<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}\n<b><i>Gate ➛ Shopify 1$</i></b>\n"
        f"<b><i>Command ➛ /sp</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
    "info_charge_payfast": (
        f"{_SEP}\n<b><i>Gate ➛ PayFast 0.30$</i></b>\n<b><i>Command ➛ /pf</i></b>\n"
        f"<b><i>Sites Loaded ➛ 1</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
    "info_charge_fatzebra": (
        f"{_SEP}\n<b><i>Gate ➛ FatZebra 4$</i></b>\n<b><i>Command ➛ /ft</i></b>\n"
        f"<b><i>Sites Loaded ➛ 1</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
    "info_charge_nmi": (
        f"{_SEP}\n<b><i>Gate ➛ NMI 1$</i></b>\n<b><i>Command ➛ /nmi</i></b>\n"
        f"<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}\n<b><i>Gate ➛ NMI2 1$</i></b>\n"
        f"<b><i>Command ➛ /nmi2</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
    "info_charge_bluepay": (
        f"{_SEP}\n<b><i>Gate ➛ BluePay 20$</i></b>\n<b><i>Command ➛ /bl</i></b>\n"
        f"<b><i>Sites Loaded ➛ 1</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
    "info_charge_authnet": (
        f"{_SEP}\n<b><i>Gate ➛ Authorize.net 1$</i></b>\n<b><i>Command ➛ /at</i></b>\n"
        f"<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
    "info_charge_payway": (
        f"{_SEP}\n<b><i>Gate ➛ PayWay 1$</i></b>\n<b><i>Command ➛ /pw</i></b>\n"
        f"<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
    "info_charge_razorpay": (
        f"{_SEP}\n<b><i>Gate ➛ Razorpay 1₹</i></b>\n<b><i>Command ➛ /rz</i></b>\n"
        f"<b><i>Sites Loaded ➛ 5</i></b>\n<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
    "info_charge_payu": (
        f"{_SEP}\n<b><i>Gate ➛ PayU 1$</i></b>\n<b><i>Command ➛ /pyu</i></b>\n"
        f"<b><i>Gate Health ➛ 100%</i></b>\n{_SEP}", _KB_BACK_CHARGE),
}

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FAST INLINE EDIT HELPER
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
async def _edit(msg: types.Message, text: str, kb: InlineKeyboardMarkup):
    try:
        if msg.caption is not None:
            await msg.edit_caption(caption=text, reply_markup=kb, parse_mode="HTML")
        else:
            await msg.edit_text(text=text, reply_markup=kb, parse_mode="HTML")
    except TypeError:
        pass
    except Exception as e:
        if "Message is not modified" not in str(e):
            logging.warning(f"_edit: {e}")

async def _safe_answer(cb: types.CallbackQuery, text: str = "", **kw):
    try:
        await cb.answer(text, **kw)
    except Exception:
        pass

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# /start
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
@router.message(Command("start"))
async def start(message: types.Message):
    user = message.from_user
    asyncio.create_task(ensure_user_and_credits(user.id, user.username))

    quick = _loading_caption(user)
    caption_task = asyncio.create_task(_get_caption(user))

    sent = await message.reply(quick, reply_markup=_MAIN_KB)

    try:
        full = await caption_task
        await sent.edit_text(text=full, reply_markup=_MAIN_KB)
    except Exception:
        pass

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# DOT COMMANDS (.chk, .st, etc.)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DOT_COMMAND_MAP = {
    "sh": sh_command,
    "bin": binn_command, "binn": binn_command,
    "sub": sub_command, "rc": rc_command, "suball": suball_command,
    "g_code": g_code_command, "gencodes": g_access_command,
    "claim": claim_command, "info": info_command,
    "rsub": rsub_command, "adcr": adcr_command,
    "on": on_command, "off": off_command, "stats": stats_command,
    "leaderboard": stats_command,
    "proxy": proxy_command, "checkproxy": checkproxy_command,
    "clearproxy": clearproxy_command, "sitechk": sitechk_command,
    "addsite": addsite_command, "siteall": siteall_command,
    "removeall": removeall_command, "dedupe": dedupe_command,
    "proxyinfo": proxyinfo_command, "resetproxy": resetproxy_command,
    "cmds": cmds_command, "fb": feedback_cmd, "broad": broad_command,
    "ban": ban_command, "unban": unban_command, "vps": vps_command,
    "admin": admin_command, "prx": prx_command,
    "addsites": addsites_command, "checksite": checksite_command,
    "restart": restart_command,
}

@router.message(F.text.regexp(r'^\.\w+'))
async def dot_command_handler(message: types.Message):
    cmd = message.text.strip().split()[0][1:].lower()
    h = DOT_COMMAND_MAP.get(cmd)
    if h:
        await h(message)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# CALLBACK HANDLER — MAXIMUM SPEED
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
_MASS_PREFIXES = ("mshs_", "mshr_", "msts_", "mstr_", "stco_", "fb_", "cmds_")

@router.callback_query()
async def button_handler(callback: types.CallbackQuery):
    data = callback.data or ""

    # These are owned by other routers — drop immediately, no answer needed
    if data.startswith(_MASS_PREFIXES):
        return

    # Guard: if the message is inaccessible (too old / deleted), bail out gracefully
    msg = callback.message
    if not isinstance(msg, types.Message):
        await _safe_answer(callback, "<tg-emoji emoji-id='5397890704062038337'>❌</tg-emoji> Message expired. Please use /start again.", show_alert=True)
        return

    user_id = callback.from_user.id

    # ── STATIC MENU (most common path) ─────────────────────────────────────
    static = STATIC_MENU_MAP.get(data)
    if static is not None:
        text, kb = static
        if kb is None:  # menu_payment_methods — kb computed at runtime
            kb = pay_sys.get_plan_selection_keyboard()
        asyncio.create_task(_safe_answer(callback))   # answer instantly — no waiting
        asyncio.create_task(_edit(msg, text, kb))     # edit in background
        return

    # ── BACK TO MAIN ───────────────────────────────────────────────────────
    if data == "back_main":
        user = callback.from_user
        quick = _loading_caption(user)
        caption_task = asyncio.create_task(_get_caption(user))
        asyncio.create_task(_safe_answer(callback))   # answer instantly — no waiting
        try:
            if msg.caption is not None:
                await msg.edit_caption(caption=quick, reply_markup=_MAIN_KB, parse_mode="HTML")
            else:
                await msg.edit_text(text=quick, reply_markup=_MAIN_KB, parse_mode="HTML")
        except TypeError:
            pass
        except Exception as e:
            if "Message is not modified" not in str(e):
                logging.warning(f"back_main load: {e}")
        try:
            full = await caption_task
            await msg.edit_caption(caption=full, reply_markup=_MAIN_KB, parse_mode="HTML")
        except TypeError:
            pass
        except Exception:
            pass
        return

    # ── PAYMENT PLAN SELECTION ──────────────────────────────────────────────
    if data.startswith("pay_plan_"):
        plan = data[9:]
        if plan not in pay_sys.PLANS:
            asyncio.create_task(_safe_answer(callback))
            asyncio.create_task(msg.answer("Invalid plan!"))
            return
        pi = pay_sys.PLANS[plan]
        pay_sys.set_user_session(user_id, plan)
        text = (
            f"<b>{pi['display']} Plan</b>\n"
            f"<b>Price ➛</b> ${pi['price']}\n"
            f"<b>Duration ➛</b> {pi['days']} Days\n"
            f"<b>Credits ➛</b> {pi['credits']:,}\n"
            f"<b>Select Payment Method:</b>"
        )
        asyncio.create_task(_safe_answer(callback))
        asyncio.create_task(_edit(msg, text, pay_sys.get_network_selection_keyboard(user_id)))
        return

    # ── BACK TO PLAN LIST ───────────────────────────────────────────────────
    if data.startswith("pay_back_plans_"):
        try:
            owner_id = int(data[15:])
        except ValueError:
            await _safe_answer(callback, "<tg-emoji emoji-id='5397890704062038337'>❌</tg-emoji> Error", show_alert=True)
            return
        if user_id != owner_id:
            await _safe_answer(callback, "<tg-emoji emoji-id='5397890704062038337'>❌</tg-emoji> No permission", show_alert=True)
            return
        asyncio.create_task(_safe_answer(callback))
        asyncio.create_task(_edit(msg, _PAYMENT_SELECT_TEXT, pay_sys.get_plan_selection_keyboard()))
        return

    # ── DIRECT PAYMENT INITIATION ───────────────────────────────────────────
    if data.startswith("pay_direct_"):
        net_key = data[11:]
        session = pay_sys.get_user_session(user_id)
        if not session or not session.get("plan"):
            asyncio.create_task(_safe_answer(callback))
            asyncio.create_task(msg.answer("Session expired!"))
            return
        plan = session["plan"]
        net_info = pay_sys.DIRECT_NETWORKS.get(net_key)
        if not net_info:
            asyncio.create_task(_safe_answer(callback))
            asyncio.create_task(msg.answer("Invalid network!"))
            return
        pay_sys.cancel_user_active_payment(user_id)
        payment_data = await asyncio.to_thread(
            pay_sys.create_payment, user_id, plan, net_info["currency"], net_info["network"]
        )
        if not payment_data:
            await asyncio.gather(
                _safe_answer(callback),
                _edit(msg, "<tg-emoji emoji-id='5397890704062038337'>❌</tg-emoji> <b>Payment Failed</b>\n\nPlease try again later.",
                      _back("menu_pricing")),
            )
            return
        track_id = payment_data["track_id"]
        pay_sys.register_payment(track_id, user_id, plan)
        caption = pay_sys.format_payment_caption(payment_data, plan)
        kb = pay_sys.get_paid_button_keyboard(track_id, user_id)
        await _safe_answer(callback)
        try:
            sent_msg = await msg.answer(text=caption, reply_markup=kb, disable_web_page_preview=True)
        except Exception as e:
            logging.error(f"pay_direct send: {e}")
            return
        try:
            await msg.delete()
        except Exception:
            pass
        if sent_msg:
            pay_sys.active_payments[track_id].update({
                "chat_id": sent_msg.chat.id,
                "message_id": sent_msg.message_id,
                "original_text": caption,
            })
        return

    # ── PAYMENT CHECK (I Paid button) ───────────────────────────────────────
    if data.startswith("pay_check_"):
        track_id = data[10:]
        payment = pay_sys.active_payments.get(track_id)
        if not payment or payment.get("user_id") != user_id:
            await _safe_answer(callback, "<tg-emoji emoji-id='5397890704062038337'>❌</tg-emoji> No permission", show_alert=True)
            return
        bot_i = pay_sys.get_bot()
        if not bot_i:
            await _safe_answer(callback, "<tg-emoji emoji-id='5397890704062038337'>❌</tg-emoji> Bot error", show_alert=True)
            return
        try:
            status = await asyncio.to_thread(pay_sys.check_payment_status, track_id)
            logging.info(f"pay_check {track_id}: {status}")
            if status and status.lower() == "paid":
                await asyncio.to_thread(pay_sys.activate_plan, user_id, payment["plan"])
                receipt = pay_sys.get_receipt_for_user(user_id, payment["plan"])
                pi = pay_sys.PLANS.get(payment["plan"], {})
                dn = callback.from_user.first_name or callback.from_user.username or "User"
                ul = f'<a href="tg://user?id={user_id}">{dn}</a>'
                mid = mask_receipt_id(receipt['receipt_id']) if receipt else "N/A"
                try:
                    await bot_i.send_message(
                        chat_id=LOG_CHANNEL_ID, parse_mode="HTML",
                        text=(f"<tg-emoji emoji-id=\"6183613910977876404\">💎</tg-emoji> <b>NEW PLAN</b>\n\n"
                              f"<tg-emoji emoji-id=\"5433641741251011862\">👤</tg-emoji> {ul}\n"
                              f"<tg-emoji emoji-id=\"5269501182258205420\">📦</tg-emoji> <b>{pi.get('display','')}</b> 🛠️\n"
                              f"<tg-emoji emoji-id=\"5922478782689579227\">💰</tg-emoji> <b>${pi.get('price',0)}</b>")
                    )
                except Exception as le:
                    logging.error(f"log channel: {le}")
                success = (
                    f"<tg-emoji emoji-id='5310296284874159738'>✅</tg-emoji> <b>Transaction Success!</b>\n\n"
                    f" <b>Plan ➛</b> {pi.get('display','')}\n"
                    f" <b>Duration ➛</b> {pi.get('days',0)} Days\n\n"
                    f" <b>Your Plan has been activated!</b>"
                )
                dm_kb = None
                if receipt:
                    dm = (f"Congratulations! <tg-emoji emoji-id='5310296284874159738'>🎉</tg-emoji> Your access has been activated.\n"
                          f"User ➛ {ul}\nAccess ➛ <b>{receipt['plan_name']}</b>\n"
                          f"Duration ➛ {receipt['days']} Days\n"
                          f"Your plan has been activated!")
                else:
                    dm = (f"Congratulations! <tg-emoji emoji-id='5310296284874159738'>🎉</tg-emoji> Your access has been activated.\n"
                          f"Access ➛ <b>{pi.get('display','')}</b>\n"
                          f"Duration ➛ {pi.get('days',0)} Days\n"
                          f"Your plan has been activated!")
                await asyncio.gather(
                    _safe_answer(callback, "<tg-emoji emoji-id='5310296284874159738'>✅</tg-emoji> Payment Confirmed! Plan activated.", show_alert=True),
                    asyncio.ensure_future(bot_i.edit_message_text(chat_id=payment["chat_id"],
                                            message_id=payment["message_id"], text=success)),
                    asyncio.ensure_future(bot_i.send_message(chat_id=user_id, text=dm, parse_mode="HTML", reply_markup=dm_kb)),
                )
                pay_sys._cleanup_payment(track_id, user_id)

            elif status and status.lower() == "expired":
                await asyncio.gather(
                    _safe_answer(callback, "<tg-emoji emoji-id='4904882772637648609'>⏰</tg-emoji> Payment Expired!", show_alert=True),
                    asyncio.ensure_future(bot_i.edit_message_text(
                        chat_id=payment["chat_id"], message_id=payment["message_id"],
                        text="<b>Payment Expired</b>\n\nThe payment window has closed.\nPlease start a new payment."
                    )),
                )
                pay_sys._cleanup_payment(track_id, user_id)

            else:
                await _safe_answer(callback, "<tg-emoji emoji-id='4904882772637648609'>⏳</tg-emoji> Payment not detected yet.\nEnsure exact amount is sent.", show_alert=True)
                cur_text = payment.get("original_text", "")
                if "Payment not detected yet" not in cur_text:
                    pending = (f"{cur_text}\n\n<tg-emoji emoji-id='4904882772637648609'>⏳</tg-emoji> <b>Payment not detected yet.</b>\n"
                               f"<i>Ensure exact amount is sent. Click 'Paid' again to recheck.</i>")
                    try:
                        await bot_i.edit_message_text(
                            chat_id=payment["chat_id"], message_id=payment["message_id"],
                            text=pending, reply_markup=pay_sys.get_paid_button_keyboard(track_id, user_id)
                        )
                        payment["original_text"] = pending
                    except Exception as e:
                        if "not modified" not in str(e):
                            logging.error(f"pending edit: {e}")
        except Exception as e:
            logging.error(f"pay_check error: {e}")
            await _safe_answer(callback, "<tg-emoji emoji-id='5350572310627632617'>⚠️</tg-emoji> Network error. Try again.", show_alert=True)
        return

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# EXPLICIT CALLBACK REGISTRATIONS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
dp.callback_query.register(msh_stop_handler, MshStopCallback.filter())
dp.callback_query.register(msh_result_handler, MshResultCallback.filter())

dp.callback_query.register(sh_callback_handler, F.data.startswith("sh_"))


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# COMMAND REGISTRATIONS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
for _cmd, _fn in [
    ("sh", sh_command),
    ("siteall", siteall_command), ("removeall", removeall_command), ("dedupe", dedupe_command),
    ("proxyinfo", proxyinfo_command), ("resetproxy", resetproxy_command),
    ("sub", sub_command), ("rc", rc_command),
    ("suball", suball_command), ("g_code", g_code_command), ("gencodes", g_access_command),
    ("claim", claim_command),
    ("info", info_command), ("rsub", rsub_command),
    ("adcr", adcr_command), ("on", on_command), ("off", off_command),
    ("stats", stats_command), ("leaderboard", stats_command),
    ("proxy", proxy_command), ("checkproxy", checkproxy_command),
    ("clearproxy", clearproxy_command), ("bin", binn_command), ("binn", binn_command),
]:
    dp.message.register(_fn, Command(_cmd))

setup_feedback_handler(dp)

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# WEBHOOK SERVER
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
from aiohttp import web

async def _resolve_handle(bot, handle: str, label: str):
    """Resolve a public @handle to its numeric chat ID. Returns the ID or None.

    Skip private invite links (t.me/+hash) — those require the bot to already
    be a member of the group/channel, so get_chat() will always fail. The
    caller falls back to the hardcoded numeric ID next to the handle.
    """
    if not handle:
        return None
    s = str(handle).strip()
    if s.startswith("https://t.me/+") or s.startswith("t.me/+"):
        logging.info(f"[startup] {label}: invite link {handle} → using hardcoded numeric ID (bot not a member, skipping resolution)")
        return None
    try:
        chat = await bot.get_chat(handle)
        logging.info(f"[startup] {label} resolved: {handle} → {chat.id}")
        return chat.id
    except Exception as e:
        logging.info(f"[startup] {label}: {handle} unresolvable ({e}); using hardcoded numeric ID")
        return None


async def _resolve_handles_on_startup(bot: Bot):
    """Resolve all @handles → numeric IDs. Runs in BOTH webhook + polling startup."""
    pay_sys.set_bot(bot)
    # Resolve feedback channel
    try:
        import fb as _fb_module
        resolved = await _fb_module.resolve_feedback_channel(bot)
        _fb_module.FEEDBACK_CHANNEL = resolved
    except Exception as e:
        logging.error(f"[startup] Could not resolve FEEDBACK_CHANNEL: {e}")
    # Resolve required channel + group
    chid = await _resolve_handle(bot, REQUIRED_CHANNEL_HANDLE, "REQUIRED_CHANNEL_ID")
    if chid is not None:
        globals()["REQUIRED_CHANNEL_ID"] = chid
    rid = await _resolve_handle(bot, REQUIRED_GROUP_HANDLE, "REQUIRED_GROUP_ID")
    if rid is not None:
        globals()["REQUIRED_GROUP_ID"] = rid
    # Resolve main LOG_CHANNEL_ID (used by main.py + sub.py)
    lid = await _resolve_handle(bot, LOG_CHANNEL_HANDLE, "LOG_CHANNEL_ID (main/sub)")
    if lid is not None:
        globals()["LOG_CHANNEL_ID"] = lid
        try:
            import sub as _sub_module
            _sub_module.LOG_CHANNEL_ID = lid
            logging.info(f"[startup] sub.LOG_CHANNEL_ID patched to {lid}")
        except Exception as e:
            logging.warning(f"[startup] Could not patch sub.LOG_CHANNEL_ID: {e}")
    # Resolve HIT_LOG_GROUP_ID + EXTRA_CHARGED_GROUP_ID in msh.py
    try:
        from mass_gates import msh as _msh_module
        hid = await _resolve_handle(bot, _msh_module.HIT_LOG_GROUP_HANDLE, "HIT_LOG_GROUP_ID")
        if hid is not None:
            _msh_module.HIT_LOG_GROUP_ID = hid
        eid = await _resolve_handle(bot, _msh_module.EXTRA_CHARGED_GROUP_HANDLE, "EXTRA_CHARGED_GROUP_ID")
        if eid is not None:
            _msh_module.EXTRA_CHARGED_GROUP_ID = eid
    except Exception as e:
        logging.warning(f"[startup] Could not patch msh log IDs: {e}")
    # Resolve HIT_LOG_GROUP_ID for gates/sh.py
    try:
        from gates import sh as _sh_module
        sh_hid = await _resolve_handle(bot, _sh_module.HIT_LOG_GROUP_HANDLE, "HIT_LOG_GROUP_ID (sh)")
        if sh_hid is not None:
            _sh_module.HIT_LOG_GROUP_ID = sh_hid
            logging.info(f"[startup] sh.HIT_LOG_GROUP_ID patched to {sh_hid}")
    except Exception as e:
        logging.warning(f"[startup] Could not patch sh.HIT_LOG_GROUP_ID: {e}")
    # Resolve HIT_LOG_GROUP_ID for fb.py
    try:
        import fb as _fb_module
        fb_hid = await _resolve_handle(bot, _fb_module.HIT_LOG_GROUP_HANDLE, "HIT_LOG_GROUP_ID (fb)")
        if fb_hid is not None:
            _fb_module.HIT_LOG_GROUP_ID = fb_hid
            logging.info(f"[startup] fb.HIT_LOG_GROUP_ID patched to {fb_hid}")
    except Exception as e:
        logging.warning(f"[startup] Could not patch fb.HIT_LOG_GROUP_ID: {e}")


async def _prewarm_shopify_api() -> None:
    """
    Pre-warm the shared HTTP session + DNS + connection pool to the
    primary Shopify API at startup. The first user request after boot
    would otherwise pay the full TCP+TLS+DNS cost; pre-warming moves
    that cost to boot time so the very first /msh is fast.
    """
    try:
        from shopify_api import _get_shared_session, SHOPIFY_API_URLS
        sess = await _get_shared_session()
        # Issue a tiny HEAD/GET to the primary host so the connector
        # pool, DNS cache and TLS session are warm before users arrive.
        primary_url = SHOPIFY_API_URLS[0][0]
        try:
            async with sess.get(
                primary_url,
                params={"card": "0|0|0|0", "url": "https://example.com",
                        "proxy": "http://127.0.0.1:1"},
                timeout=aiohttp.ClientTimeout(total=8),
            ) as resp:
                # We don't care about the body — we just want the connection.
                await resp.read()
                logging.info(f"[startup] pre-warmed {primary_url} → HTTP {resp.status}")
        except Exception as e:
            # Pre-warm failures are non-fatal; real traffic will retry.
            logging.debug(f"[startup] pre-warm probe failed (non-fatal): {e}")
    except Exception as e:
        logging.debug(f"[startup] pre-warm skipped: {e}")


async def on_startup(bot: Bot):
    await bot.set_webhook(WEBHOOK_URL)
    await _resolve_handles_on_startup(bot)
    await _prewarm_shopify_api()
    logging.info(f"Webhook set: {WEBHOOK_URL}")

async def on_shutdown(bot: Bot):
    await bot.delete_webhook()
    try:
        from shopify_api import close_shared_session
        await close_shared_session()
    except Exception:
        pass
    logging.info("Webhook deleted")

async def webhook_handler(request):
    try:
        data = await request.json()
        update = types.Update.model_validate(data)
    except Exception as e:
        logging.error(f"webhook parse: {e}")
        return web.Response(status=200)
    try:
        await dp.feed_update(bot, update)
    except TypeError:
        pass
    except Exception as e:
        logging.error(f"webhook: {e}")
    return web.Response(status=200)

def main():
    if LOCAL_MODE:
        # ── Polling mode (local development) ──────────────────
        import asyncio
        async def _run_polling():
            await bot.delete_webhook(drop_pending_updates=True)
            await _resolve_handles_on_startup(bot)
            await _prewarm_shopify_api()
            logging.info("Bot starting via Polling (LOCAL MODE)…")
            await dp.start_polling(bot)
        asyncio.run(_run_polling())
    else:
        # ── Webhook mode (Railway / production) ───────────────
        app = web.Application()
        app.on_startup.append(lambda _: on_startup(bot))
        app.on_shutdown.append(lambda _: on_shutdown(bot))
        app.router.add_post(f"/{BOT_TOKEN}", webhook_handler)
        logging.info("Bot starting via Webhook…")
        web.run_app(app, host=WEBHOST, port=WEBPORT)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logging.info("Bot stopped.")
